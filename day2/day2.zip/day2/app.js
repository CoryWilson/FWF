function myController($scope){

  $scope.movieArray = [];
  $scope.movie = {};

  $scope.formSubmit = function(){

    $scope.movieArray.push($scope.movie);
    $scope.movie = {};
  };
  $scope.movieDelete = function(idx){
    $scope.movieArray.splice(idx,1);
  };
}
